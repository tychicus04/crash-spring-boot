package com.tychicus.WestLakeHotel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WestLakeHotelApplicationTests {

	@Test
	void contextLoads() {
	}

}
