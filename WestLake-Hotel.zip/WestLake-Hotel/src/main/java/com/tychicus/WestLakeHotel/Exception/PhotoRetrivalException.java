package com.tychicus.WestLakeHotel.Exception;

public class PhotoRetrivalException extends RuntimeException {
    public PhotoRetrivalException(String message) {
        super(message);
    }
}
